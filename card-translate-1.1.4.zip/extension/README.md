# Card Translate — 网页自动翻译扩展

轻量级浏览器扩展：**自动检测英文网页，以完整句子 / 段落为单位实时翻译成简体中文**。
Manifest V3，零构建、零 npm 依赖，解压即可加载。
**自带免费公共网络翻译通道，不搭服务器也能开箱即用。**

## 核心特性

- **开箱即用**：内置免密钥公共翻译通道（主：Google 公共接口；备：MyMemory 自动兜底），无需搭服务器、无需任何 API Key
- **整句翻译，不打碎片**：内联标签（strong/span/em…）的文本自动合并进所在段落，一句话只发一次请求
- **实时感**：视口优先（IntersectionObserver + 700px 预翻区），打开页面首屏立刻开始翻，滚到哪翻到哪
- **动态网页支持**：MutationObserver 接管 SPA / 无限滚动 / 懒加载，带确定性防递归（按「改动来源」判定，不是靠计时器）
- **请求高效**：同文本共享 Promise 去重、攒批发送、失败指数退避（1s→2s→…封顶 30s）
- **轻量缓存**：页面内存去重 + 本地 LRU（默认 5000 条上限），不引入数据库
- **随时恢复原文**：译文写回前原文始终留在内存，切换原文/译文不重新请求
- **服务器可插拔**：统一 `TranslatorProvider` 接口，换翻译引擎不改网页端
- **最小权限**：只申请 `storage`；网络统一走后台 service worker
- **链接/表单不坏**：只改文字，不碰 href/onclick/class/id/data-*；用户输入永不被翻译

## 安装（加载已解压的扩展程序）

1. 打开浏览器的扩展管理页：
   - Chrome：地址栏输入 `chrome://extensions`
   - Edge：`edge://extensions`
   - Brave / Vivaldi / Opera 同理
2. 打开右上角「**开发者模式**」
3. 点「**加载已解压的扩展程序**」，选择本文件夹（`extension/`）
4. 完成。**无需安装 Python / Node / 任何运行环境**

**卡片浏览器桌面版**：设置 → 扩展 → 加载已解压的扩展程序，同样选本文件夹
（v1.1.2 起支持；更新插件文件后，在扩展列表里删除再重新加载一次，避免后台脚本用旧缓存）。

## 快速开始

1. 装完即用：默认走「自带公共网络翻译」通道，直接打开任意英文网页就会自动翻译
2. 想完全自控？设置 → 服务类型 → 「自定义 REST 服务器」，填自己的服务器地址
3. 想不联网验证链路？服务类型切「调试：无服务器回显」，打开 `test/test-page.html`

## 翻译服务器

### 自带通道（默认，免服务器）

走公共翻译接口，免密钥、无需部署、无需 API Key：

| 优先级 | 端点 | 说明 |
| --- | --- | --- |
| 主 | `translate.googleapis.com/translate_a/t`（公共翻译接口） | 质量好、速度快，一次请求带多条文本（自动按 URL 长度分片） |
| 备 | `api.mymemory.translated.net` | 主通道失败时自动逐条兜底（有每日匿名额度） |

两个端点是扩展仅有的两个 `host_permissions`（权限最小化）。若所在网络两个都不可达，
请改用下面的自定义服务器或 LibreTranslate。

### 自定义协议（可选）

```text
POST https://你的服务器/v1/translate
Content-Type: application/json

请求: { "source": "en", "target": "zh-CN",
        "texts": ["完整句子一。", "完整句子二。"],
        "glossary": ["GitHub", "Windows"] }        // glossary 可选

响应: { "translations": ["完整句子一的中文。", "完整句子二的中文。"] }
```

要求：`translations` 与 `texts` 一一对应、长度一致；服务器需允许跨域（CORS）。

### 参考实现`../server/` 目录有一个零依赖 Node 参考服务器（含演示引擎 + LibreTranslate 兼容层），
详见 `../server/README.md`。接真引擎（Argos / LibreTranslate / 自训练模型）只改服务器，
**扩展端一行不用动**。

## 目录结构

```text
extension/
├── manifest.json            MV3 清单（权限只有 storage）
├── background/
│   └── service-worker.js    网络层：拿配置 → 调 Provider
├── content/
│   ├── content.js           总调度：检测→扫描→视口→队列→写回
│   ├── detector.js          语言检测（整页 + 单条）
│   ├── dom-scanner.js       DOM 分段（核心：整句合并规则）
│   ├── translator.js        翻译队列（批量/去重/退避）
│   ├── apply.js             写回与原文恢复
│   ├── mutation-watcher.js  动态监听（防递归）
│   └── viewport-scheduler.js 视口优先调度
├── providers/               TranslatorProvider 接口 + 三个实现
├── cache/                   内存去重 + 本地 LRU 缓存
├── popup/  options/         弹窗与设置页
├── shared/                  配置/日志/工具/语言判断
└── test/test-page.html      全场景测试页
```

## 性能设计

- 首屏文本一批发出，不等整页扫描完；滚动接近的内容提前 700px 开始翻
- 一个请求默认最多 30 条 / 4000 字符（设置页可调），同文本 30 处出现只发一次
- 翻译结果未返回前页面保持英文原样，**零布局跳动**（不删字、不清空、不重排）
- 断网 / 服务器挂了：保持英文，指数退避，网络恢复后新内容自动继续翻
- 已移除节点定期清扫，长时间开着不涨内存

## 隐私与安全

- 不收集浏览历史、不上传 Cookie / 密码 / 页面 HTML，只发送**需要翻译的文本**
- 自带通道会把待翻译文本发给对应的公共服务（Google 公共接口 / MyMemory）；
  想完全自控数据流向，就换「自定义服务器」并指向自己的机器
- 服务器返回内容只按纯文本处理，绝无 eval/innerHTML 注入
- 不内置任何 API Key；鉴权 Token 字段仅在你自己的服务器要求时才填

## 已知边界（v1）

- 跨域 iframe、closed Shadow DOM 不翻译（遵守浏览器安全边界）；open Shadow DOM 后续版本支持
- `code`/`pre` 整体跳过（纯代码保护优先于「pre 里也可能有散文」）
- 品牌词保护（Windows → 窗口 这类问题）：请求里带了 glossary 字段，需要服务器配合落实
- Firefox 适配：API 调用已集中在少量文件，未做跨浏览器兼容层（第二阶段再做）
- Electron 桌面端（卡片浏览器）：无 `chrome.storage.sync`，插件自动退回 `local`
  （设置不跨设备同步，功能不受影响）

## 使用授权
个人和公司员工日常使用免费；销售插件、集成到收费产品或对外提供收费服务需另行书面授权。详见 [LICENSE](LICENSE)。历史 MIT 版本授权不变。

