// DOM 扫描 / 分段（本项目最核心的模块）。
//
// 设计目标：绝不把一句话拆成碎片去翻。
// 原理（吸收 domtranslator / Linguist 的已验证思路后用零依赖实现）：
//   1) 递归遍历 DOM，收集「块级元素自己直接拥有的文本节点」；
//   2) 内联元素（span/strong/em/b/i...）的文本向上合并进最近的块级祖先，
//      所以 <p>Hello <strong>John</strong>, welcome</p> 是一个完整翻译单元；
//   3) <a>/<button>/<option> 永远是独立单元 —— 保住 href 和点击行为；
//   4) 块级子元素各自成为独立单元 —— <div><p>A</p><p>B</p></div> 不会把两段挤进同一个节点；
//   5) 跳过 script/style/code/pre/textarea/contenteditable/notranslate/[translate=no]。

const SELF_UNIT_TAGS = new Set(['A', 'BUTTON', 'OPTION', 'OPTGROUP']);

const BLOCK_TAGS = new Set([
  'ADDRESS', 'ARTICLE', 'ASIDE', 'BLOCKQUOTE', 'CAPTION', 'DETAILS', 'DD', 'DIV', 'DL', 'DT',
  'FIELDSET', 'FIGCAPTION', 'FIGURE', 'FOOTER', 'FORM', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
  'HEADER', 'LEGEND', 'LI', 'MAIN', 'NAV', 'OL', 'P', 'SECTION', 'SUMMARY', 'TABLE',
  'TD', 'TH', 'THEAD', 'TBODY', 'TFOOT', 'TR', 'UL',
]);

const SKIP_TAGS = new Set([
  'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'TEMPLATE', 'SVG', 'MATH', 'CODE', 'PRE',
  'SELECT', 'IFRAME', 'CANVAS', 'AUDIO', 'VIDEO', 'SOURCE', 'TRACK', 'OBJECT', 'EMBED',
  'MAP', 'DIALOG', 'INPUT', 'HEAD', 'META', 'LINK', 'BASE', 'TITLE',
]);

// 至少要有一个拉丁字母才可能值得翻（我们只做 英->中）
const LATIN_LETTER_RE = /[A-Za-z\u00C0-\u024F]/;

export function shouldSkipElement(el) {
  const tag = el.tagName;
  if (SKIP_TAGS.has(tag)) return true;
  if (el.hidden) return true;
  if (el.isContentEditable) return true;
  if (el.getAttribute && el.getAttribute('translate') === 'no') return true;
  const cls = el.classList;
  if (cls && (cls.contains('notranslate') || cls.contains('no-translate'))) return true;
  return false;
}

function makeElementUnit(el, nodes) {
  return { kind: 'element', el, nodes, text: '' }; // text 由调用方用 joinSegments 填
}

// 递归扫描。返回：
//   units    —— 该子树下确定的翻译单元
//   ownNodes —— 需要并入更外层块级收集器的文本节点（内联文本向上合并）
function scanElement(el) {
  if (shouldSkipElement(el)) return { units: [], ownNodes: [] };

  const units = [];
  const ownNodes = [];
  const isSelfUnit = SELF_UNIT_TAGS.has(el.tagName);
  const isBlock = BLOCK_TAGS.has(el.tagName);

  for (const child of el.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      if (LATIN_LETTER_RE.test(child.nodeValue)) ownNodes.push(child);
    } else if (child.nodeType === Node.ELEMENT_NODE) {
      const r = scanElement(child);
      units.push(...r.units);
      ownNodes.push(...r.ownNodes);
    }
  }

  // 链接/按钮/option、以及块级元素：自己成为单元，文本不再向上冒
  if (isSelfUnit || isBlock) {
    if (ownNodes.length) units.push(makeElementUnit(el, ownNodes));
    return { units, ownNodes: [] };
  }
  // 内联元素：文本继续向上合并（保持整句完整）
  return { units, ownNodes };
}

// 可翻译属性：按钮 value、placeholder、title、aria-label、alt
const ATTR_TARGETS = [
  { attr: 'title' },
  { attr: 'aria-label' },
  { attr: 'placeholder', tags: new Set(['INPUT', 'TEXTAREA']) },
  { attr: 'alt', tags: new Set(['IMG', 'AREA']) },
  {
    attr: 'value',
    tags: new Set(['INPUT']),
    inputTypes: new Set(['submit', 'button', 'reset']),
  },
];

function collectAttrUnits(root) {
  const units = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let el;
  while ((el = walker.nextNode())) {
    // INPUT/TEXTAREA 自身在文本扫描里被跳过（没有子文本节点），
    // 但它们的 placeholder / value 属性需要翻译，这里必须放行。
    const isFormControl = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA';
    if (!isFormControl && shouldSkipElement(el)) continue;
    for (const t of ATTR_TARGETS) {
      if (t.tags && !t.tags.has(el.tagName)) continue;
      if (t.inputTypes) {
        if (el.tagName !== 'INPUT' || !t.inputTypes.has((el.type || '').toLowerCase())) continue;
      }
      const val = el.getAttribute(t.attr);
      if (val && LATIN_LETTER_RE.test(val)) {
        units.push({ kind: 'attr', el, attr: t.attr, text: val });
      }
    }
  }
  return units;
}

/**
 * 扫出 root 子树下所有翻译单元。
 * 返回数组元素形如：
 *   { kind:'element', el, nodes:[Text,...], text }
 *   { kind:'attr', el, attr, text }
 * 注意：不在这里过滤语言/垃圾文本，由调用方决定（扫描器保持纯粹）。
 */
export function scanUnits(root) {
  const target = root && root.nodeType === Node.ELEMENT_NODE ? root : document.body;
  if (!target) return [];

  const { units, ownNodes } = scanElement(target);
  // 顶层散文本（不在任何块级元素里的），以 root 为单元兜底
  if (ownNodes.length) units.push(makeElementUnit(target, ownNodes));

  units.push(...collectAttrUnits(target));
  return units;
}
