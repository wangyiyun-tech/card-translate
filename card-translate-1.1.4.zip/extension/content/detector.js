// 语言检测：整页级 + 单条文本级。

import { guessPageLang, isLikelyNonChinese } from '../shared/lang.js';
import { isNonTranslatable } from '../shared/utils.js';

// 取页面可见文本样本做整页判断（innerText 浏览器会自动排除不可见内容）
export function samplePageText(maxChars = 4000) {
  const t = document.body?.innerText || document.body?.textContent || '';
  return t.slice(0, maxChars);
}

export function detectPage() {
  const lang = guessPageLang(samplePageText(), document.documentElement?.lang || '');
  return { lang };
}

// 一条文本是否值得送翻（过滤中文、URL、纯数字等碎片）
export function isUsableText(text) {
  const t = (text || '').trim();
  if (!t) return false;
  if (t.length > 10000) return false;
  if (isNonTranslatable(t)) return false;
  if (!isLikelyNonChinese(t)) return false; // 已经是中文，不动
  return true;
}
