// 内容脚本引导入口（经典脚本，不能有 import/export）。
// 限制说明：manifest 的 content_scripts 不支持 "type": "module"，
// 所以这里用动态 import 拉起真正的 ES 模块入口 content.js；
// 被引用的模块目录已列入 manifest 的 web_accessible_resources。
import(chrome.runtime.getURL('content/content.js'));
