// 翻译队列：批量、去重、共享 Promise、指数退避。
//
// 关键点：
// - 相同文本只发一次请求，其余共享同一个 Promise；
// - 攒批发送（条数/字符数双上限），不是一条一个请求；
// - 失败时指数退避（1s -> 2s -> ... 封顶 30s），绝不无限重试；
// - 失败的文本 resolve 为 null，调用方保持英文原样，页面永远不坏。

import { logger } from '../shared/logger.js';

export class TranslationQueue {
  constructor({ sendTranslate, cache, maxBatchItems, maxBatchChars, maxConcurrent }) {
    this.send = sendTranslate; // async (texts[]) => translations[]，由 content.js 提供桥
    this.cache = cache;
    this.maxBatchItems = Math.max(1, maxBatchItems || 30);
    this.maxBatchChars = Math.max(200, maxBatchChars || 4000);
    this.maxConcurrent = Math.max(1, maxConcurrent || 4);

    this.shared = new Map(); // key -> Promise<string|null>
    this.waiting = []; // { key, text, resolve }
    this.inFlight = 0;
    this.failStreak = 0;
    this.backoffUntil = 0;
    this._scheduled = false;

    this.stats = { requested: 0, cacheHits: 0, batches: 0, failed: 0 };
  }

  /**
   * 批量翻译。返回 Map<原文, 译文|null>。
   * 同批调用会自动攒进同一个请求。
   */
  async translateMany(texts) {
    const results = new Map();
    const jobs = [];

    for (const text of texts) {
      this.stats.requested++;
      const key = this.cache.keyOf(text);

      const hit = this.cache.get(key);
      if (hit !== null) {
        this.stats.cacheHits++;
        results.set(text, hit);
        continue;
      }
      const existing = this.shared.get(key);
      if (existing) {
        jobs.push([text, existing]);
        continue;
      }
      const p = this._enqueue(key, text);
      this.shared.set(key, p);
      jobs.push([text, p]);
    }

    await Promise.all(jobs.map(async ([text, p]) => results.set(text, await p)));
    return results;
  }

  _enqueue(key, text) {
    return new Promise((resolve) => {
      this.waiting.push({ key, text, resolve });
      this._schedule();
    });
  }

  _schedule() {
    if (this._scheduled) return;
    this._scheduled = true;
    // 用 setTimeout(0) 把同一个任务里入队的文本攒成一批发
    setTimeout(() => {
      this._scheduled = false;
      this._pump();
    }, 0);
  }

  async _pump() {
    if (this.inFlight >= this.maxConcurrent) return;

    const now = Date.now();
    if (now < this.backoffUntil) {
      setTimeout(() => this._pump(), this.backoffUntil - now + 10);
      return;
    }

    const batch = [];
    let chars = 0;
    while (
      this.waiting.length &&
      batch.length < this.maxBatchItems &&
      chars < this.maxBatchChars
    ) {
      const item = this.waiting[0];
      if (batch.length > 0 && chars + item.text.length > this.maxBatchChars) break;
      this.waiting.shift();
      batch.push(item);
      chars += item.text.length;
    }
    if (!batch.length) return;

    this.inFlight++;
    this.stats.batches++;
    const texts = batch.map((b) => b.text);

    let translations = null;
    try {
      translations = await this.send(texts);
    } catch (e) {
      logger.warn('翻译批次失败:', e?.message || e);
    }
    this.inFlight--;

    if (Array.isArray(translations) && translations.length === texts.length) {
      this.failStreak = 0;
      batch.forEach((b, i) => {
        const t = translations[i];
        if (typeof t === 'string' && t) {
          this.cache.set(b.key, t);
          this.shared.delete(b.key);
          b.resolve(t);
        } else {
          this.shared.delete(b.key);
          b.resolve(null);
          this.stats.failed++;
        }
      });
    } else {
      // 失败：退避，所有等待者拿到 null（保持原文）
      this.failStreak++;
      this.backoffUntil = Date.now() + Math.min(30000, 1000 * 2 ** this.failStreak);
      batch.forEach((b) => {
        this.shared.delete(b.key);
        b.resolve(null);
        this.stats.failed++;
      });
    }

    // 队列里还有就继续打
    this._pump();
  }
}
