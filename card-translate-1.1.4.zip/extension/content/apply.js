// 翻译结果管理：写回、恢复原文、再次应用。
//
// 写回原则（保护页面不坏）：
// - 译文写进单元的第一个文本节点，其余文本节点清空（内联标签保留，只是变空壳，无害）；
// - 绝不碰 innerHTML、绝不碰 href/onclick/class/id/data-*；
// - 原文一直留在内存里，恢复 = 把原值写回去，不重新请求服务器；
// - 每个翻译过的元素打 data-ct 标记，React/Vue 重渲染时靠它识别。

export class TranslationStore {
  constructor() {
    this.records = new Map(); // id -> rec
    this.nodeOwner = new Map(); // TextNode -> rec
    this.elIndex = new Map(); // Element -> Set<rec>
    this.attrKeys = new WeakMap(); // Element -> Set<attr>，防止属性单元重复登记
    this.nextId = 1;
  }

  addElementUnit({ el, nodes, text }) {
    const id = this.nextId++;
    const rec = {
      id,
      kind: 'element',
      el,
      nodes: nodes.map((n) => ({ node: n, value: n.nodeValue })),
      sourceText: text,
      translatedText: null,
      state: 'pending',
    };
    this._register(rec);
    return rec;
  }

  addAttrUnit({ el, attr, text }) {
    let attrs = this.attrKeys.get(el);
    if (attrs && attrs.has(attr)) return null;
    if (!attrs) {
      attrs = new Set();
      this.attrKeys.set(el, attrs);
    }
    attrs.add(attr);
    const id = this.nextId++;
    const rec = {
      id,
      kind: 'attr',
      el,
      attr,
      originalValue: el.getAttribute(attr),
      sourceText: text,
      translatedText: null,
      state: 'pending',
    };
    this._register(rec);
    return rec;
  }

  _register(rec) {
    this.records.set(rec.id, rec);
    if (rec.kind === 'element') {
      for (const n of rec.nodes) this.nodeOwner.set(n.node, rec);
    }
    let set = this.elIndex.get(rec.el);
    if (!set) {
      set = new Set();
      this.elIndex.set(rec.el, set);
    }
    set.add(rec);
  }

  /** 存译文；apply=false 表示只存不写（比如用户已点了暂停） */
  setTranslation(rec, translation, { apply = true } = {}) {
    rec.translatedText = typeof translation === 'string' && translation ? translation : null;
    rec.state = rec.translatedText ? 'translated' : 'failed';
    if (apply && rec.translatedText) this.apply(rec);
  }

  apply(rec) {
    try {
      if (rec.kind === 'element') {
        const ns = rec.nodes;
        if (!ns.length) return;
        ns[0].node.nodeValue = rec.translatedText;
        for (let i = 1; i < ns.length; i++) {
          if (ns[i].node.nodeValue !== '') ns[i].node.nodeValue = '';
        }
        rec.el.setAttribute('data-ct', '1');
      } else {
        rec.el.setAttribute(rec.attr, rec.translatedText);
      }
      rec.state = 'translated';
    } catch {
      // 节点可能已被页面移除，忽略
    }
  }

  restore(rec) {
    try {
      if (rec.kind === 'element') {
        for (const n of rec.nodes) {
          if (n.node.nodeValue !== n.value) n.node.nodeValue = n.value;
        }
        rec.el.removeAttribute('data-ct');
      } else if (rec.originalValue === null) {
        rec.el.removeAttribute(rec.attr);
      } else {
        rec.el.setAttribute(rec.attr, rec.originalValue);
      }
      rec.state = 'pending'; // 恢复后可再次应用已缓存的译文
    } catch {
      // 忽略
    }
  }

  restoreAll() {
    for (const rec of this.records.values()) {
      if (rec.state === 'translated' || rec.state === 'failed') this.restore(rec);
    }
  }

  applyAll() {
    for (const rec of this.records.values()) {
      if (rec.translatedText) this.apply(rec);
    }
  }

  /** 某元素被页面重渲染后：撤掉它的旧记录、释放节点占用，让上层重新扫描 */
  removeForElement(el) {
    const set = this.elIndex.get(el);
    if (!set) return;
    for (const rec of [...set]) {
      if (rec.kind === 'element') {
        for (const n of rec.nodes) this.nodeOwner.delete(n.node);
      }
      this.records.delete(rec.id);
      set.delete(rec);
    }
    if (!set.size) this.elIndex.delete(el);
    this.attrKeys.delete(el);
  }

  /** 清理已被页面移除的节点，防内存涨 */
  sweep() {
    let removed = 0;
    for (const rec of [...this.records.values()]) {
      if (rec.el && !rec.el.isConnected) {
        if (rec.kind === 'element') {
          for (const n of rec.nodes) this.nodeOwner.delete(n.node);
        }
        const set = this.elIndex.get(rec.el);
        if (set) {
          set.delete(rec);
          if (!set.size) this.elIndex.delete(rec.el);
        }
        this.records.delete(rec.id);
        removed++;
      }
    }
    return removed;
  }

  count() {
    let translated = 0;
    let failed = 0;
    let pending = 0;
    for (const r of this.records.values()) {
      if (r.state === 'translated') translated++;
      else if (r.state === 'failed') failed++;
      else pending++;
    }
    return { translated, failed, pending, total: this.records.size };
  }
}
