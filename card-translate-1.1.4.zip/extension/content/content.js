// 内容脚本总调度。
// 流程：装配置 -> 检测页面语言 -> 扫描翻译单元 -> 视口调度 -> 队列翻译 -> 写回。
// 动态内容：MutationObserver 持续接管新增/被页面改写的内容。

import { loadConfig, saveConfig, onConfigChanged } from '../shared/config.js';
import { setDebugLog, logger } from '../shared/logger.js';
import { getHostname, matchesSite, debounce, joinSegments } from '../shared/utils.js';
import { TranslationCache } from '../cache/translation-cache.js';
import { detectPage, isUsableText } from './detector.js';
import { scanUnits } from './dom-scanner.js';
import { TranslationQueue } from './translator.js';
import { TranslationStore } from './apply.js';
import { createViewportScheduler } from './viewport-scheduler.js';
import { watchMutations } from './mutation-watcher.js';

let config = null;
let queue = null;
let scheduler = null;
const store = new TranslationStore();

let pageMode = 'idle'; // idle | translating | paused
let detectedLang = 'unknown';
const host = getHostname(location.href);
const claimed = new WeakSet(); // 已被某个单元占用的文本节点，防止重复扫描时二次登记

// ---------- 与后台通信（网络统一走后台，内容脚本不直接 fetch） ----------
async function sendTranslate(texts) {
  const res = await chrome.runtime.sendMessage({
    type: 'ct_translate',
    texts,
    source: config.sourceLang,
    target: config.targetLang,
  });
  if (!res || !res.ok) throw new Error(res?.error || '后台翻译失败');
  return res.translations;
}

function initQueue() {
  const cache = new TranslationCache({
    enabled: config.cacheEnabled,
    maxEntries: config.cacheMaxEntries,
    keyPrefix: `${config.provider}|${config.sourceLang}|${config.targetLang}|`,
  });
  queue = new TranslationQueue({
    sendTranslate,
    cache,
    maxBatchItems: config.maxBatchItems,
    maxBatchChars: config.maxBatchChars,
    maxConcurrent: config.maxConcurrent,
  });
}

// ---------- 扫描登记 ----------
function collectAndRegister(root) {
  const recs = [];
  if (!root || root.nodeType !== Node.ELEMENT_NODE) return recs;

  for (const u of scanUnits(root)) {
    if (u.kind === 'element') {
      const nodes = u.nodes.filter((n) => !claimed.has(n));
      if (!nodes.length) continue;
      const text = joinSegments(nodes.map((n) => n.nodeValue));
      if (!isUsableText(text)) continue;
      const rec = store.addElementUnit({ el: u.el, nodes, text });
      for (const n of nodes) claimed.add(n);
      recs.push(rec);
    } else {
      if (!isUsableText(u.text)) continue;
      const rec = store.addAttrUnit(u);
      if (rec) recs.push(rec);
    }
  }
  return recs;
}

// ---------- 翻译执行 ----------
async function translateRecords(recs) {
  const items = [];
  for (const rec of recs) {
    if (!rec || rec.state !== 'pending') continue;
    const text =
      rec.kind === 'element'
        ? joinSegments(rec.nodes.map((n) => n.node.nodeValue))
        : rec.el.getAttribute(rec.attr) || '';
    if (!isUsableText(text)) {
      rec.state = 'skipped';
      continue;
    }
    rec.sourceText = text;
    items.push([rec, text]);
  }
  if (!items.length) return;

  logger.debug('本批发起翻译条数:', items.length);
  let results;
  try {
    results = await queue.translateMany(items.map((i) => i[1]));
  } catch (e) {
    logger.warn('翻译请求异常:', e?.message || e);
    return;
  }
  for (const [rec, text] of items) {
    // 暂停状态下只存不写，用户再点「显示译文」时可以应用
    store.setTranslation(rec, results.get(text), { apply: pageMode === 'translating' });
  }
  scheduleRetry(items.map((i) => i[0]));
}

// ---------- 失败自动重试：网络抖动/接口限流时，翻不动的段落隔几秒再试 ----------
// 没有这套机制时，一批请求失败 = 那些段落永远停在英文（这就是「有些翻不了」的根源）。

function nearViewport(el) {
  try {
    const r = el.getBoundingClientRect();
    return r.bottom > -800 && r.top < window.innerHeight + 800;
  } catch {
    return false;
  }
}

function scheduleRetry(recs) {
  const failed = recs.filter((r) => r && r.state === 'failed');
  if (!failed.length) return;
  for (const rec of failed) rec.retryCount = (rec.retryCount || 0) + 1;
  const eligible = failed.filter((r) => r.retryCount <= 3);
  if (!eligible.length) {
    logger.warn(`${failed.length} 个单元重试 3 次仍失败，保持英文原文（换个网络或稍后刷新可再试）`);
    return;
  }
  const round = Math.max(...eligible.map((r) => r.retryCount));
  setTimeout(() => {
    if (pageMode !== 'translating') return;
    const todo = eligible.filter((r) => r.state === 'failed' && r.el?.isConnected);
    if (!todo.length) return;
    logger.debug(`自动重试失败单元 ${todo.length} 个（第 ${round} 轮）`);
    for (const r of todo) r.state = 'pending';
    translateRecords(todo);
  }, 6000 * round);
}

function onVisible(el) {
  const set = store.elIndex.get(el);
  if (!set || pageMode !== 'translating') return;
  // 曾经翻失败、又滚回视口内的：给一次重试机会
  for (const rec of set) {
    if (rec.state === 'failed' && (rec.retryCount || 0) <= 3) rec.state = 'pending';
  }
  translateRecords([...set]);
}

async function retranslateRecord(rec) {
  logger.debug('页面脚本改写了已翻译单元，重新翻译');
  const text =
    rec.kind === 'element'
      ? joinSegments(rec.nodes.map((n) => n.node.nodeValue))
      : rec.el.getAttribute(rec.attr) || '';
  if (!isUsableText(text)) return;
  rec.state = 'pending';
  rec.sourceText = text;
  const results = await queue.translateMany([text]);
  store.setTranslation(rec, results.get(text), { apply: pageMode === 'translating' });
}

// ---------- 动态内容 ----------
const addedBuffer = [];
const flushAdded = debounce(() => {
  if (pageMode !== 'translating') {
    addedBuffer.length = 0;
    return;
  }
  const nodes = addedBuffer.splice(0);
  const recs = [];
  for (const n of nodes) recs.push(...collectAndRegister(n));
  for (const r of recs) scheduler.observe(r.el);
  store.sweep(); // 顺手清理已被页面移除的节点
}, 80);

function handleAddedNodes(nodes) {
  addedBuffer.push(...nodes);
  flushAdded();
}

function handleTextChanged(node) {
  if (pageMode !== 'translating') return;

  const rec = store.nodeOwner.get(node);
  if (rec) {
    if (rec.state !== 'translated') return;
    const v = node.nodeValue;
    if (v === rec.translatedText || v === '') return; // 我们自己写的，忽略（防递归）
    // 页面脚本把译文改回了英文（React/Vue 重渲染）-> 重翻该单元
    retranslateRecord(rec);
    return;
  }

  // 不归我们管的新文本：若出现在已翻译元素里，重扫该元素
  let el = node.parentElement;
  for (let i = 0; el && i < 4; i++, el = el.parentElement) {
    if (el.hasAttribute && el.hasAttribute('data-ct')) {
      logger.debug('已翻译元素内出现新文本，重扫:', el.tagName);
      store.removeForElement(el);
      for (const r of collectAndRegister(el)) scheduler.observe(r.el);
      return;
    }
  }
}

// ---------- 启停 ----------
async function startTranslation() {
  if (pageMode === 'translating') return;
  pageMode = 'translating';
  collectAndRegister(document.body);
  logger.info(`开始翻译：共 ${store.records.size} 个翻译单元`);
  // 重新排程所有待翻译单元：已有译文的（之前暂停/恢复过）立即应用，
  // 没译文的交给视口调度（首屏和附近内容 IntersectionObserver 会立刻回调）。
  for (const rec of store.records.values()) {
    if (rec.state !== 'pending') continue;
    if (rec.translatedText) store.apply(rec);
    else scheduler.observe(rec.el);
  }
}

function stopTranslation({ restore = true } = {}) {
  pageMode = 'paused';
  scheduler.disconnect();
  if (restore) store.restoreAll();
}

// ---------- popup 消息 ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg?.type) {
        case 'ct_getStatus':
          sendResponse({
            ok: true,
            host,
            detectedLang,
            pageMode,
            counts: store.count(),
            autoTranslate: !!config?.autoTranslate,
            alwaysSite: matchesSite(host, config?.alwaysTranslateSites),
            provider: config?.provider,
          });
          break;
        case 'ct_translatePage':
          await startTranslation();
          sendResponse({ ok: true });
          break;
        case 'ct_restorePage':
          stopTranslation({ restore: true });
          sendResponse({ ok: true });
          break;
        case 'ct_showOriginal':
          store.restoreAll();
          sendResponse({ ok: true });
          break;
        case 'ct_showTranslation':
          store.applyAll();
          sendResponse({ ok: true });
          break;
        case 'ct_setAlwaysSite': {
          const on = !!msg.on;
          const list = new Set(config.alwaysTranslateSites || []);
          if (on) list.add(host);
          else list.delete(host);
          config.alwaysTranslateSites = [...list];
          await saveConfig({ alwaysTranslateSites: config.alwaysTranslateSites });
          if (on && pageMode !== 'translating') await startTranslation();
          sendResponse({ ok: true });
          break;
        }
        default:
          sendResponse({ ok: false, error: '未知消息' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();
  return true; // 异步 sendResponse
});

// ---------- 入口 ----------
async function main() {
  config = await loadConfig();
  setDebugLog(config.debugLog);
  initQueue();
  scheduler = createViewportScheduler(onVisible);
  watchMutations({ onAddedNodes: handleAddedNodes, onTextChanged: handleTextChanged });
  setInterval(() => {
    if (pageMode === 'translating') store.sweep();
  }, 60000);

  // 兜底清扫：视口附近翻失败的段落，每 15 秒再排一次队
  setInterval(() => {
    if (pageMode !== 'translating') return;
    const todo = [];
    for (const rec of store.records.values()) {
      if (
        rec.state === 'failed' &&
        (rec.retryCount || 0) <= 3 &&
        rec.el?.isConnected &&
        nearViewport(rec.el)
      ) {
        rec.state = 'pending';
        todo.push(rec);
      }
    }
    if (todo.length) {
      logger.debug(`兜底重试视口附近失败单元 ${todo.length} 个`);
      translateRecords(todo);
    }
  }, 15000);

  detectedLang = detectPage().lang;

  onConfigChanged((changes) => {
    for (const [k, v] of Object.entries(changes)) config[k] = v.newValue;
    setDebugLog(config.debugLog);
  });

  if (matchesSite(host, config.neverTranslateSites)) return; // 永不翻译名单
  const always = matchesSite(host, config.alwaysTranslateSites);
  if (always || (config.autoTranslate && detectedLang === 'en')) {
    startTranslation();
  }
}

main().catch((e) => {
  // 启动失败的兜底：让问题在页面控制台可见，而不是静默消失
  console.error('[CardTranslate] 启动失败:', e);
});
