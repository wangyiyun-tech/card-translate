// 视口调度：滚到哪翻到哪，首屏永远最先翻。
// IntersectionObserver + 700px 预翻区（提前翻即将滚入的内容，用户无感）。

export function createViewportScheduler(onVisible, rootMargin = '700px') {
  if (typeof IntersectionObserver === 'undefined') {
    // 极老浏览器兜底：退化成「看见就翻」（直接全部翻）
    return {
      observe(el) {
        queueMicrotask(() => onVisible(el));
      },
      unobserve() {},
      disconnect() {},
    };
  }

  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (e.isIntersecting) {
          io.unobserve(e.target);
          onVisible(e.target);
        }
      }
    },
    { rootMargin }
  );

  return {
    observe(el) {
      io.observe(el);
    },
    unobserve(el) {
      io.unobserve(el);
    },
    disconnect() {
      io.disconnect();
    },
  };
}
