// 动态内容监听（SPA / 无限滚动 / 懒加载）。
//
// 防递归不靠计时器，靠「来源判定」，确定性更强：
// - childList 新增节点 = 页面自己加的 -> 交上层扫描翻译；
// - characterData 变化：节点归我们管时，
//     · 值 === 译文或空串 -> 是我们自己写的，忽略；
//     · 值变回英文 -> 页面脚本改写了（React 重渲染），通知上层重翻；
//   节点不归我们管 -> 新内容，交给上层。

export function watchMutations({ onAddedNodes, onTextChanged }) {
  const mo = new MutationObserver((mutations) => {
    const added = [];
    const changedTexts = new Set();

    for (const m of mutations) {
      if (m.type === 'childList') {
        for (const n of m.addedNodes) {
          if (n.nodeType === Node.ELEMENT_NODE) added.push(n);
          else if (n.nodeType === Node.TEXT_NODE) changedTexts.add(n);
        }
      } else if (m.type === 'characterData') {
        changedTexts.add(m.target);
      }
    }

    if (added.length) onAddedNodes(added);
    for (const t of changedTexts) onTextChanged(t);
  });

  mo.observe(document.documentElement, {
    subtree: true,
    childList: true,
    characterData: true,
  });

  return () => mo.disconnect();
}
