import { DEFAULT_CONFIG, loadConfig, saveConfig } from '../shared/config.js';
import { TranslationCache } from '../cache/translation-cache.js';

const $ = (id) => document.getElementById(id);

function fillForm(c) {
  $('autoTranslate').checked = !!c.autoTranslate;
  $('provider').value = c.provider;
  $('serverUrl').value = c.serverUrl;
  $('libretranslateUrl').value = c.libretranslateUrl;
  $('apiKey').value = c.apiKey || '';
  $('alwaysSites').value = (c.alwaysTranslateSites || []).join('\n');
  $('neverSites').value = (c.neverTranslateSites || []).join('\n');
  $('maxBatchItems').value = c.maxBatchItems;
  $('maxBatchChars').value = c.maxBatchChars;
  $('maxConcurrent').value = c.maxConcurrent;
  $('requestTimeoutMs').value = c.requestTimeoutMs;
  $('protectedTerms').value = (c.protectedTerms || []).join(', ');
  $('cacheEnabled').checked = !!c.cacheEnabled;
  $('cacheMaxEntries').value = c.cacheMaxEntries;
  $('debugLog').checked = !!c.debugLog;
  updateProviderFields();
}

function readForm() {
  const num = (id, min, max, fallback) => {
    const v = parseInt($(id).value, 10);
    return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
  };
  const lines = (id) =>
    $(id).value.split(/\n+/).map((s) => s.trim()).filter(Boolean);
  return {
    autoTranslate: $('autoTranslate').checked,
    provider: $('provider').value,
    serverUrl: $('serverUrl').value.trim(),
    libretranslateUrl: $('libretranslateUrl').value.trim(),
    apiKey: $('apiKey').value.trim(),
    alwaysTranslateSites: lines('alwaysSites'),
    neverTranslateSites: lines('neverSites'),
    maxBatchItems: num('maxBatchItems', 1, 200, DEFAULT_CONFIG.maxBatchItems),
    maxBatchChars: num('maxBatchChars', 200, 50000, DEFAULT_CONFIG.maxBatchChars),
    maxConcurrent: num('maxConcurrent', 1, 10, DEFAULT_CONFIG.maxConcurrent),
    requestTimeoutMs: num('requestTimeoutMs', 2000, 60000, DEFAULT_CONFIG.requestTimeoutMs),
    protectedTerms: $('protectedTerms').value.split(/[,，\n]+/).map((s) => s.trim()).filter(Boolean),
    cacheEnabled: $('cacheEnabled').checked,
    cacheMaxEntries: num('cacheMaxEntries', 100, 50000, DEFAULT_CONFIG.cacheMaxEntries),
    debugLog: $('debugLog').checked,
  };
}

function updateProviderFields() {
  const p = $('provider').value;
  $('fieldServerUrl').style.display = p === 'custom' ? '' : 'none';
  $('fieldLibreUrl').style.display = p === 'libretranslate' ? '' : 'none';
}

function tip(text) {
  $('saveTip').textContent = text;
  setTimeout(() => ($('saveTip').textContent = ''), 2500);
}

async function showCacheInfo() {
  const c = new TranslationCache({
    enabled: true,
    maxEntries: parseInt($('cacheMaxEntries').value, 10) || DEFAULT_CONFIG.cacheMaxEntries,
  });
  await c._loaded;
  $('cacheInfo').textContent = `当前缓存 ${c.size} 条`;
}

async function init() {
  fillForm(await loadConfig());
  showCacheInfo();

  $('provider').addEventListener('change', updateProviderFields);

  $('saveBtn').addEventListener('click', async () => {
    await saveConfig(readForm());
    tip('已保存');
  });

  $('resetBtn').addEventListener('click', async () => {
    await saveConfig(DEFAULT_CONFIG);
    fillForm(DEFAULT_CONFIG);
    tip('已恢复默认');
  });

  $('clearCacheBtn').addEventListener('click', async () => {
    const c = new TranslationCache({ enabled: true });
    await c._loaded;
    await c.clear();
    showCacheInfo();
    tip('缓存已清理');
  });
}

init();
