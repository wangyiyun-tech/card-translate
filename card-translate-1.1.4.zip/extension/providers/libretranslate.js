// LibreTranslate 兼容 Provider（可选，不作依赖）。
// POST {libretranslateUrl}  body: { q: string[], source, target, format: 'text' }
// 响应: { translatedText: string[] }（q 传数组时返回数组；个别老版本只回字符串，这里做了兜底）

import { TranslatorProvider, fetchJson } from './provider-base.js';

export class LibreTranslateProvider extends TranslatorProvider {
  get id() {
    return 'libretranslate';
  }

  async translate(texts, source, target) {
    const data = await fetchJson(this.config.libretranslateUrl, {
      headers: this._headers(),
      body: JSON.stringify({ q: texts, source, target, format: 'text' }),
      timeoutMs: this.config.requestTimeoutMs,
    });
    let out = data?.translatedText;
    if (typeof out === 'string') out = texts.length === 1 ? [out] : null;
    if (!Array.isArray(out) || out.length !== texts.length) {
      throw new Error('LibreTranslate 返回格式不正确');
    }
    return out.map((v) => (typeof v === 'string' ? v : String(v ?? '')));
  }

  _headers() {
    const h = { 'Content-Type': 'application/json' };
    if (this.config.apiKey) h['Authorization'] = 'Bearer ' + this.config.apiKey;
    return h;
  }
}
