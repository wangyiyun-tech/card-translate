// 自带公共网络翻译通道（默认 Provider，免服务器、免密钥、开箱即用）。
//
// 主通道：Google 公共翻译接口（translate_a/t，非官方 gtx 端点）
//   - 支持多 q 批量：一次 GET 翻多条，实测返回 ["译文1","译文2",...] 与请求一一对应
//   - 按 URL 长度预算自动分片，避免超长 URL 被拒
// 备通道：MyMemory 免费公共 API（主通道整体失败时逐条兜底，有每日匿名额度）
//
// 两个端点都在 manifest 的 host_permissions 里声明（仅这两个域名，最小化）。
// 注意：这些是公共服务，质量与可用性由对方决定；想完全自控就换「自定义服务器」Provider。

import { TranslatorProvider } from './provider-base.js';

const GOOGLE_T = 'https://translate.googleapis.com/translate_a/t';
const MYMEMORY = 'https://api.mymemory.translated.net/get';

// 单次 GET 的 URL 编码字符预算（保守值，避开各类中间设备长度限制）
const URL_BUDGET = 1500;

async function getJson(url, timeoutMs) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(new Error('请求超时')), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      credentials: 'omit',
      cache: 'no-store',
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export class WebFreeProvider extends TranslatorProvider {
  get id() {
    return 'web-free';
  }

  async translate(texts, source, target) {
    try {
      return await this._google(texts, source, target);
    } catch (e) {
      // 主通道整体失败 -> MyMemory 逐条兜底
      return await this._mymemory(texts, source, target);
    }
  }

  async _google(texts, source, target) {
    const out = [];
    let chunk = [];
    let budget = 0;

    const flush = async () => {
      if (!chunk.length) return;
      const url =
        GOOGLE_T +
        `?client=gtx&dt=t&sl=${encodeURIComponent(source)}&tl=${encodeURIComponent(target)}&` +
        chunk.map((t) => 'q=' + encodeURIComponent(t)).join('&');
      const j = await getJson(url, this.config.requestTimeoutMs);
      if (!Array.isArray(j) || j.length !== chunk.length) {
        throw new Error('公共接口返回格式不正确');
      }
      for (const v of j) {
        if (typeof v === 'string') out.push(v);
        else if (Array.isArray(v)) out.push(String(v[0] ?? ''));
        else out.push('');
      }
      chunk = [];
      budget = 0;
    };

    for (const t of texts) {
      const enc = encodeURIComponent(t).length + 3;
      if (chunk.length && budget + enc > URL_BUDGET) await flush();
      chunk.push(t);
      budget += enc;
    }
    await flush();
    return out;
  }

  async _mymemory(texts, source, target) {
    const pair = `${source}|${target}`;
    const results = [];
    for (const t of texts) {
      try {
        // MyMemory 单条约 500 字符上限：长段落按句子切开逐段翻，再拼回去
        const pieces = splitForMyMemory(t);
        const out = [];
        let ok = true;
        for (const piece of pieces) {
          const url =
            MYMEMORY +
            '?q=' + encodeURIComponent(piece) +
            '&langpair=' + encodeURIComponent(pair);
          const j = await getJson(url, this.config.requestTimeoutMs);
          const tr = j?.responseData?.translatedText;
          if (j?.responseStatus === 200 && typeof tr === 'string' && tr && !tr.includes('MYMEMORY WARNING')) {
            out.push(tr);
          } else {
            ok = false; // 配额超限（403）或警告响应：按失败处理，交给重试
            break;
          }
        }
        results.push(ok ? out.join('') : '');
      } catch {
        results.push('');
      }
    }
    return results;
  }
}

// 按句子边界把长文本切成 MyMemory 能接受的长度（≤450 字符）
function splitForMyMemory(text, maxLen = 450) {
  if (text.length <= maxLen) return [text];
  const sentences = text.split(/(?<=[.!?。！？])\s+/);
  const parts = [];
  let cur = '';
  for (const s of sentences) {
    if (cur && (cur + ' ' + s).length > maxLen) {
      parts.push(cur);
      cur = s;
    } else {
      cur = cur ? cur + ' ' + s : s;
    }
    // 单句超长的兜底：硬切
    while (cur.length > maxLen) {
      parts.push(cur.slice(0, maxLen));
      cur = cur.slice(maxLen);
    }
  }
  if (cur) parts.push(cur);
  return parts;
}
