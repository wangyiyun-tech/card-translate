// Provider 注册表：加新翻译后端 = 在这里加一行，网页翻译核心完全不用动。

import { WebFreeProvider } from './web-free.js';
import { CustomApiProvider } from './custom-api.js';
import { LibreTranslateProvider } from './libretranslate.js';
import { DebugEchoProvider } from './debug-echo.js';

export const PROVIDER_CLASSES = {
  'web-free': WebFreeProvider,
  custom: CustomApiProvider,
  libretranslate: LibreTranslateProvider,
  'debug-echo': DebugEchoProvider,
};

export function createProvider(config) {
  const Ctor = PROVIDER_CLASSES[config.provider] || CustomApiProvider;
  return new Ctor(config);
}
