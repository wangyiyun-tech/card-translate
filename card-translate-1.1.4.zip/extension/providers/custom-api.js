// 自定义 REST 翻译服务器 Provider（第一版默认）。
// 协议（简单、自己实现服务器很容易）：
//   POST {serverUrl}
//   请求体: { "source": "en", "target": "zh-CN", "texts": ["...", "..."], "glossary": ["GitHub", ...] }
//   响应体: { "translations": ["...", "..."] }   // 与 texts 一一对应、长度一致
// glossary 是可选项：服务器如果支持，应优先保留这些词不翻译。

import { TranslatorProvider, fetchJson } from './provider-base.js';

export class CustomApiProvider extends TranslatorProvider {
  get id() {
    return 'custom';
  }

  async translate(texts, source, target) {
    const body = { source, target, texts };
    const glossary = this.config.protectedTerms;
    if (Array.isArray(glossary) && glossary.length) body.glossary = glossary;

    const data = await fetchJson(this.config.serverUrl, {
      headers: this._headers(),
      body: JSON.stringify(body),
      timeoutMs: this.config.requestTimeoutMs,
    });

    const out = Array.isArray(data)
      ? data
      : (data?.translations ?? data?.translatedTexts ?? data?.translatedText);
    if (!Array.isArray(out) || out.length !== texts.length) {
      throw new Error('服务器返回格式不正确：需要与请求等长的 translations 数组');
    }
    return out.map((v) => (typeof v === 'string' ? v : v == null ? '' : String(v)));
  }

  _headers() {
    const h = { 'Content-Type': 'application/json' };
    if (this.config.apiKey) h['Authorization'] = 'Bearer ' + this.config.apiKey;
    return h;
  }
}
