// TranslatorProvider 统一接口。
// 网页翻译核心只认识这个接口；换翻译服务器 = 换 Provider 实现，其余一行不动。

export class TranslatorProvider {
  constructor(config) {
    this.config = config;
  }

  get id() {
    return 'base';
  }

  /**
   * @param {string[]} texts 完整句子/段落数组
   * @param {string} source 源语言，如 'en'
   * @param {string} target 目标语言，如 'zh-CN'
   * @returns {Promise<string[]>} 与 texts 一一对应的译文数组
   */
  async translate(texts, source, target) {
    throw new Error('Provider 未实现 translate()');
  }
}

// 带超时的 JSON 请求。出错时不带网页内容，避免把用户文本写进日志。
export async function fetchJson(url, { method = 'POST', headers = {}, body, timeoutMs = 15000 }) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(new Error('请求超时')), timeoutMs);
  try {
    const res = await fetch(url, {
      method,
      headers,
      body,
      signal: ctrl.signal,
      credentials: 'omit',
      cache: 'no-store',
    });
    if (!res.ok) {
      const brief = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}${brief ? ' ' + brief.slice(0, 80) : ''}`);
    }
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}
