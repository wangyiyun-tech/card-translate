// 【调试专用】无服务器回显 Provider：不联网，直接回一个带标记的假译文。
// 用途：你的翻译服务器还没就绪时，先验证「检测 -> 分段 -> 队列 -> 写回」整条链路通不通。
// 明确标注是调试功能，不是真翻译。

import { TranslatorProvider } from './provider-base.js';

export class DebugEchoProvider extends TranslatorProvider {
  get id() {
    return 'debug-echo';
  }

  async translate(texts) {
    // 模拟一点网络延迟，接近真实节奏
    await new Promise((r) => setTimeout(r, 120));
    return texts.map((t) => '【演示】' + t);
  }
}
