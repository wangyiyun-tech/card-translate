// 轻量翻译缓存，两层：
// 1) 内存 Map：当前页面会话内去重（一个页面 30 个 "Learn more" 只发一次请求）
// 2) chrome.storage.local 的 LRU：跨页面、跨会话复用，带容量上限，绝不无限增长
// 故意不做服务器端大缓存、不引入数据库——实时翻译靠的是服务器快，不是缓存堆。

const STORE_KEY = 'ct_cache_v1';

export class TranslationCache {
  constructor({ enabled = true, maxEntries = 5000, keyPrefix = '' } = {}) {
    this.enabled = !!enabled;
    this.maxEntries = Math.max(100, maxEntries | 0);
    this.keyPrefix = keyPrefix;
    this.mem = new Map(); // key -> { t, ts }
    this._saveTimer = null;
    this._loaded = this._load();
  }

  keyOf(text) {
    return this.keyPrefix + text;
  }

  get(key) {
    const hit = this.mem.get(key);
    if (!hit) return null;
    // 顺手做 LRU 触摸
    hit.ts = Date.now();
    return hit.t;
  }

  set(key, translation) {
    if (!this.enabled) return;
    this.mem.set(key, { t: translation, ts: Date.now() });
    this._evictAndSave();
  }

  async _load() {
    if (!this.enabled) return;
    try {
      const o = (await chrome.storage.local.get(STORE_KEY))[STORE_KEY];
      if (o && typeof o === 'object') {
        for (const [k, v] of Object.entries(o)) {
          if (v && typeof v.t === 'string') this.mem.set(k, { t: v.t, ts: v.ts || 0 });
        }
      }
    } catch {
      // 存储坏了不影响翻译，继续用内存层
    }
  }

  _evictAndSave() {
    if (this.mem.size > this.maxEntries) {
      const arr = [...this.mem.entries()].sort((a, b) => a[1].ts - b[1].ts);
      while (arr.length > this.maxEntries) {
        const [k] = arr.shift();
        this.mem.delete(k);
      }
    }
    if (!this._saveTimer) {
      this._saveTimer = setTimeout(() => {
        this._saveTimer = null;
        this._save();
      }, 2000);
    }
  }

  async _save() {
    if (!this.enabled) return;
    try {
      await chrome.storage.local.set({ [STORE_KEY]: Object.fromEntries(this.mem) });
    } catch {
      // 忽略：缓存写失败不影响功能
    }
  }

  async clear() {
    this.mem.clear();
    try {
      await chrome.storage.local.remove(STORE_KEY);
    } catch {
      // 忽略
    }
  }

  get size() {
    return this.mem.size;
  }
}
