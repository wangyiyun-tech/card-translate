import { loadConfig, saveConfig } from '../shared/config.js';

const $ = (id) => document.getElementById(id);
let tabId = null;

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function sendToTab(type, extra = {}) {
  if (!tabId) return Promise.resolve(null);
  return chrome.tabs.sendMessage(tabId, { type, ...extra }).catch(() => null);
}

const LANG_NAMES = { en: '英文', zh: '中文', unknown: '未知' };

function renderStatus(st) {
  const btnTranslate = $('translateBtn');
  const btnOriginal = $('showOriginalBtn');
  const btnTranslation = $('showTranslationBtn');
  const alwaysSite = $('alwaysSite');

  if (!st || !st.ok) {
    $('host').textContent = '此页面不支持（浏览器内置页等）';
    $('lang').textContent = '—';
    $('status').textContent = '—';
    btnTranslate.disabled = btnOriginal.disabled = btnTranslation.disabled = true;
    alwaysSite.disabled = true;
    return;
  }

  $('host').textContent = st.host || '—';
  $('lang').textContent = LANG_NAMES[st.detectedLang] || st.detectedLang || '—';

  const c = st.counts || {};
  let s;
  if (st.pageMode === 'translating') s = `翻译中（已译 ${c.translated} 段）`;
  else if (c.translated > 0) s = `已译 ${c.translated} 段`;
  else if (st.pageMode === 'paused') s = '已暂停';
  else s = '未翻译';
  if (c.failed > 0) s += `，失败 ${c.failed}`;
  $('status').textContent = s;

  alwaysSite.checked = !!st.alwaysSite;
  btnTranslate.disabled = st.pageMode === 'translating';
  btnOriginal.disabled = btnTranslation.disabled = c.total === 0;
}

async function refreshStatus() {
  renderStatus(await sendToTab('ct_getStatus'));
}

async function init() {
  const config = await loadConfig();
  $('autoTranslate').checked = !!config.autoTranslate;

  const tab = await getActiveTab();
  tabId = tab?.id ?? null;
  await refreshStatus();

  $('autoTranslate').addEventListener('change', (e) =>
    saveConfig({ autoTranslate: e.target.checked })
  );

  $('alwaysSite').addEventListener('change', async (e) => {
    await sendToTab('ct_setAlwaysSite', { on: e.target.checked });
    refreshStatus();
  });

  $('translateBtn').addEventListener('click', async () => {
    await sendToTab('ct_translatePage');
    setTimeout(refreshStatus, 800);
  });

  $('showOriginalBtn').addEventListener('click', async () => {
    await sendToTab('ct_showOriginal');
    refreshStatus();
  });

  $('showTranslationBtn').addEventListener('click', async () => {
    await sendToTab('ct_showTranslation');
    refreshStatus();
  });

  $('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());
}

init();
