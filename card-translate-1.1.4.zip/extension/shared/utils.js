// 通用小工具：只放真正跨模块复用的东西。

// 把同一段落里被内联标签（<strong>/<span> 等）拆开的文本节点拼回去。
// 相邻两端都是字母/数字时补一个空格，避免把两个词粘成 "Helloworld" 这种假词。
export function joinSegments(parts) {
  let out = '';
  for (const p of parts) {
    if (!p) continue;
    if (out && /[\w)\]»”'’.,!?;:]$/.test(out) && /^[\w(\[«“'‘]/.test(p)) {
      out += ' ';
    }
    out += p;
  }
  return out;
}

// 这些内容不值得发去翻译：URL、邮箱、纯数字/标点、哈希、文件路径、超短标识。
const NON_TRANSLATABLE_RES = [
  /^\s*$/,
  /^(https?:\/\/|www\.)\S+$/i,
  /^[\w.+-]+@[\w-]+\.[\w.-]+$/,
  /^[\d\s.,:+\-()/[%#°]+$/,
  /^[a-f0-9]{16,}$/i,
  /^(?:[A-Za-z]:)?[\\/][\w\\/. -]+$/,
  /^[A-Za-z0-9_-]{1,2}$/,
];

export function isNonTranslatable(text) {
  const t = text.trim();
  return NON_TRANSLATABLE_RES.some((re) => re.test(t));
}

export function getHostname(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

// 网站规则匹配：'github.com' 能匹配 'gist.github.com'；列表项允许带前导点。
export function matchesSite(host, list) {
  if (!host) return false;
  return (list || []).some((d) => {
    const domain = String(d).trim().replace(/^\./, '').toLowerCase();
    if (!domain) return false;
    return host === domain || host.endsWith('.' + domain);
  });
}

export function debounce(fn, ms) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}
