// 语言判断：只用字符比例 + html lang，不引第三方库。
// 注意别把「中国发布了新的 Windows 软件」这种中文页误判成英文页。

const CJK_RE = /[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]/g;
// 拉丁 + 希腊 + 西里尔，都算「非中文文字」
const OTHER_RE = /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]/g;

export function langStats(text) {
  const cjk = (text.match(CJK_RE) || []).length;
  const other = (text.match(OTHER_RE) || []).length;
  return { cjk, other };
}

// 单条文本是不是「非中文为主」（即值得送去做 英->中 翻译）
export function isLikelyNonChinese(text) {
  const { cjk, other } = langStats(text);
  if (cjk + other === 0) return false;
  return other / (cjk + other) >= 0.5;
}

// 整页语言猜测。
// 2026-09-25 重要修正：html lang **不再无条件信任**——实测有网络链路（系统代理层）
// 会把英文页改写 lang="zh-Hans-CN"（还只汉化了表格短字段），导致插件误判「已是中文页」
// 而整页罢工。规则改为：lang 与正文字符比例互相校验，**正文比例占优的一方说了算**；
// 只有正文样本太少（不足 80 字符）时才单独采信 html lang。
export function guessPageLang(text, htmlLang) {
  const l = (htmlLang || '').trim().toLowerCase();
  const { cjk, other } = langStats(text);
  if (cjk + other < 80) {
    // 正文太少，只能信 html lang
    if (l.startsWith('zh')) return 'zh';
    if (l.startsWith('en')) return 'en';
    return 'unknown';
  }
  const otherRatio = other / (cjk + other);
  // 正文说了算：明显非中文为主 → en；明显中文为主 → zh
  if (otherRatio > 0.6) return 'en';
  if (otherRatio < 0.4) return 'zh';
  // 正文五五开（少见），退回 html lang 裁决
  if (l.startsWith('zh')) return 'zh';
  if (l.startsWith('en')) return 'en';
  return otherRatio > 0.5 ? 'en' : 'zh';
}
