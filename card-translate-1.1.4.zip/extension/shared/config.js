// 所有配置的唯一出处。换服务器只改这里的默认值或设置页，不许散落在别的文件里。

export const DEFAULT_CONFIG = {
  // 基本
  autoTranslate: true, // 自动翻译英文网页
  debugLog: false,

  // 翻译服务器（Provider）
  // web-free = 自带公共网络翻译通道（默认，免服务器免密钥开箱即用）
  provider: 'web-free', // web-free | custom | libretranslate | debug-echo
  serverUrl: 'https://translate.example.com/v1/translate',
  libretranslateUrl: 'http://localhost:5000/translate',
  // 仅当你自己的服务器要求鉴权时才填；普通使用完全不需要 API Key。
  apiKey: '',

  // 语言（第一版只做 英文 -> 简体中文）
  sourceLang: 'en',
  targetLang: 'zh-CN',

  // 批量与并发（保守默认值，设置页可调）
  maxBatchItems: 30, // 一个请求最多带多少条文本
  maxBatchChars: 4000, // 一个请求最多带多少字符
  maxConcurrent: 4, // 同时在途的请求数
  requestTimeoutMs: 15000,

  // 缓存（轻量：页面内存去重 + 本地 LRU，不做大缓存）
  cacheEnabled: true,
  cacheMaxEntries: 5000,

  // 网站规则
  alwaysTranslateSites: [], // 例如 ['github.com']
  neverTranslateSites: [],

  // 品牌词保护：随请求发给服务器（服务器应优先保留这些词不翻译）。
  // 客户端不能强行保证服务器遵守，协议里留了这个口子。
  protectedTerms: [
    'GitHub', 'Google', 'Microsoft', 'Windows', 'iPhone', 'iPad',
    'Android', 'OpenAI', 'Chrome', 'Linux', 'macOS', 'API', 'URL',
  ],
};

// 存储区自适应：Chrome/Edge 用 storage.sync（设置跨设备同步）；
// Electron（卡片浏览器桌面端）只实现了 storage.local，碰 .sync 直接抛
// "sync is not available in this instance of Chrome" —— 所以必须探测后再用。
let _area = undefined;

async function storageArea() {
  if (_area) return _area;
  try {
    // 注意：Electron 对不支持的 API 是「返回 rejected Promise」而不是同步抛错，
    // 所以必须 await 才能探测出来。
    await chrome.storage.sync.get({});
    _area = chrome.storage.sync;
  } catch {
    _area = chrome.storage.local;
  }
  return _area;
}

export async function loadConfig() {
  const area = await storageArea();
  const got = await area.get(DEFAULT_CONFIG);
  return { ...DEFAULT_CONFIG, ...got };
}

export async function saveConfig(partial) {
  const area = await storageArea();
  await area.set(partial);
}

export function onConfigChanged(cb) {
  // 不筛 area：Electron 走 local，浏览器走 sync，两边都要能收到变更
  chrome.storage.onChanged.addListener((changes, area) => cb(changes, area));
}
