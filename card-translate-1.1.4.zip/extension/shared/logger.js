// 统一日志：正式版默认静默，设置里打开 debugLog 后才输出 debug/info。
// warn/error 只在真正出问题时打印，不算日志噪音。
let debugEnabled = false;

export function setDebugLog(enabled) {
  debugEnabled = !!enabled;
}

export const logger = {
  debug(...args) {
    if (debugEnabled) console.debug('[CardTranslate]', ...args);
  },
  info(...args) {
    if (debugEnabled) console.info('[CardTranslate]', ...args);
  },
  warn(...args) {
    console.warn('[CardTranslate]', ...args);
  },
  error(...args) {
    console.error('[CardTranslate]', ...args);
  },
};
