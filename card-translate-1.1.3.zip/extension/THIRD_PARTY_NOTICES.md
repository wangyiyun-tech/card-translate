# THIRD_PARTY_NOTICES — 第三方组件与参考来源

## 本扩展代码

Card Translate 扩展本体为原创实现，采用 **MIT License** 发布。
未复制任何第三方项目的代码进入本仓库。

## 研究参考（只借鉴架构思想，未复制代码）

开发前按要求调研了以下项目。结论：它们都是 TypeScript/npm 构建产物，直接引入
会违背本项目「最终包零构建、解压即用」的硬要求，因此只吸收其已验证的架构思路，
用零依赖原生 ESM 重新实现。

| 项目 | 地址 | 许可证 | 借鉴了什么 |
| --- | --- | --- | --- |
| domtranslator | https://github.com/translate-tools/domtranslator | Apache-2.0（以仓库 LICENSE 为准） | MutationObserver 动态翻译的防递归思路、IntersectionObserver 懒翻译（视口优先）、原文保存与恢复的映射模型 |
| Linguist | https://github.com/translate-tools/linguist | 以仓库 LICENSE 为准 | 「翻译后端可替换」的架构分层（对应本项目的 TranslatorProvider 接口） |
| chrome-translator-extension | https://github.com/rennerdo30/chrome-translator-extension | 以仓库 LICENSE 为准 | 验证了 Manifest V3 + 纯 HTML/CSS/JS 无构建可行；批量翻译 + 缓存 + 动态内容检测的组合方式 |

## 使用的技术（均为浏览器标准能力，无第三方依赖）

- TreeWalker / MutationObserver / IntersectionObserver（DOM API）
- chrome.storage / chrome.runtime 消息（扩展 API）
- PNG 图标由 `_tools/gen-ct-icons.js` 纯 Node（zlib 内置模块）生成，无第三方库

## 承诺

如未来引入任何第三方代码或资源，必须先核许可证（接受 MIT / BSD / Apache-2.0 /
MPL-2.0；拒绝 GPL/AGPL 传染），并在本文件登记：项目名、地址、版本/commit、许可证、
实际使用的部分、是否修改。
