// 视口调度：滚到哪翻到哪，首屏永远最先翻。
// IntersectionObserver + 700px 预翻区（提前翻即将滚入的内容，用户无感）。

export function createViewportScheduler(onVisible, rootMargin = '700px') {
  // Electron 的嵌入页首次激活时可能遗漏 IntersectionObserver 通知。
  // 首屏与后续滚动同时检查实际布局，回调只派发一次。
  const pending = new Set();
  const margin = Number.parseFloat(rootMargin) || 0;
  let disconnected = false;
  let scheduled = false;
  const deliver = (el) => {
    if (!pending.delete(el) || disconnected) return;
    io?.unobserve(el);
    onVisible(el);
  };
  const check = () => {
    scheduled = false;
    if (disconnected || document.visibilityState === 'hidden') return;
    for (const el of pending) {
      if (!el.isConnected) { pending.delete(el); io?.unobserve(el); continue; }
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && r.bottom >= -margin &&
          r.top <= innerHeight + margin && r.right >= 0 && r.left <= innerWidth) deliver(el);
    }
  };
  const schedule = () => {
    if (scheduled || disconnected) return;
    scheduled = true;
    queueMicrotask(check);
  };
  let io = null;
  if (typeof IntersectionObserver !== 'undefined') io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (e.isIntersecting) {
          deliver(e.target);
        }
      }
    },
    { rootMargin }
  );

  document.addEventListener('scroll', schedule, true);
  document.addEventListener('visibilitychange', schedule);
  window.addEventListener('resize', schedule);

  return {
    observe(el) {
      if (disconnected) return;
      pending.add(el);
      io?.observe(el);
      schedule();
    },
    unobserve(el) {
      io?.unobserve(el);
      pending.delete(el);
    },
    disconnect() {
      io?.disconnect();
      disconnected = true;
      pending.clear();
      document.removeEventListener('scroll', schedule, true);
      document.removeEventListener('visibilitychange', schedule);
      window.removeEventListener('resize', schedule);
    },
  };
}
