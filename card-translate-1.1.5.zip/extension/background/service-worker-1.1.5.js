// Release 1.1.5: refresh the service worker module graph on extension upgrade.
// 后台 Service Worker：只做一件事——拿着配置调 Provider 拿译文。
// 网络统一走这里，内容脚本不直接 fetch；以后换翻译引擎只动 providers/。
// v1.1.2：配置存储自适应（Electron 无 storage.sync 时自动退回 local）。
// v1.1.3：整页语言判定修正——html lang 不再无条件信任（实测有代理层会把英文页
//         改写成 lang="zh-Hans-CN" 导致整页罢工），lang 与正文字符比例互相校验。
// 注意：改了本文件之外的其他模块后，务必也动一下本文件（哪怕加个注释），
// 否则 Chromium 会认为 SW 未更新、继续用缓存的旧模块图。

import { createProvider } from '../providers/index.js';
import { loadConfig } from '../shared/config.js';
import { logger, setDebugLog } from '../shared/logger.js';

let provider = null;
let providerKey = '';

async function getProvider() {
  const cfg = await loadConfig();
  setDebugLog(cfg.debugLog);
  const key = [cfg.provider, cfg.serverUrl, cfg.libretranslateUrl, cfg.apiKey].join('|');
  if (!provider || providerKey !== key) {
    provider = createProvider(cfg);
    providerKey = key;
    logger.info('使用翻译 Provider:', provider.id);
  }
  return provider;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'ct_translate') {
    (async () => {
      try {
        if (!Array.isArray(msg.texts) || !msg.texts.length) throw new Error('texts 为空');
        const p = await getProvider();
        const translations = await p.translate(msg.texts, msg.source, msg.target);
        sendResponse({ ok: true, translations });
      } catch (e) {
        logger.warn('翻译失败:', e?.message || e);
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true; // 异步 sendResponse
  }
  // 其他消息不处理
});
